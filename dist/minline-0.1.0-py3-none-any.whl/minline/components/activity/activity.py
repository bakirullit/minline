class Activity:
    def __init__(self, menu_id: str = None, lang: str = "en"):
        self.menu_id = menu_id
        self.lang = lang
